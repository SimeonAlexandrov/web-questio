<?php
$config=array(
    'DB_HOST' => 'php-app-db.mysql.database.azure.com',
    'DB_USER' => 'phpappuser@php-app-db',
    'DB_PASS' => 'MySQLAzure2018',
    'DB_NAME' => 'questio'
);

// $config=array(
//     'DB_HOST' => 'localhost',
//     'DB_USER' => 'root',
//     'DB_PASS' => '',
//     'DB_NAME' => 'questio'
// );
?>